package com.rak.rakapp;

import java.util.ArrayList;
import java.util.List;

import com.rak.rakapp.DAO.XworkzDAO;
import com.rak.rakapp.DAO.XworkzDAOImpl;
import com.rak.rakapp.DTO.XworkzDTO;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XworkzDTO dto=new XworkzDTO();
		/*dto.setS_name("manu");
		dto.setCourse("java");
		
		XworkzDTO dto1=new XworkzDTO();
		dto1.setS_name("nikunj");
		dto1.setCourse("jee");
		
		XworkzDTO dto2=new XworkzDTO();
		dto2.setS_name("deepak");
		dto2.setCourse("sql");
		
		XworkzDTO dto3=new XworkzDTO();
		dto3.setS_name("praveen");
		dto3.setCourse("fw");
		
		XworkzDTO dto4=new XworkzDTO();
		dto4.setS_name("mahajan");
		dto4.setCourse("wt");
		
		
		
		
		List<XworkzDTO> l=new ArrayList<>();
		l.add(dto);
		l.add(dto1);
		l.add(dto2);
		l.add(dto3);
		l.add(dto4);*/
		
		XworkzDAO dao=new XworkzDAOImpl();
		//dao.save(l);
		List<XworkzDTO> x=dao.fetchNameById(1);
		System.out.println(x);
	}

}
