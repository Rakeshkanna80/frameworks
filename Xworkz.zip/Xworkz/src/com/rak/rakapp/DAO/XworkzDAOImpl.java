package com.rak.rakapp.DAO;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.rak.rakapp.DTO.XworkzDTO;
import com.rak.rakapp.hibernate.util.HibernateUtil;

public class XworkzDAOImpl implements XworkzDAO {

	@Override
	public void save(List<XworkzDTO> list) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getfactory().openSession();
		try {

			Transaction transaction = session.beginTransaction();
			for (XworkzDTO xworkzDTO : list) {
				session.save(xworkzDTO);
			}

			transaction.commit();

		} catch (HibernateException e) {
			// TODO: handle exception
			System.err.println("exception in saving" + e.getMessage());
		}

	}

	@Override
	public List<XworkzDTO> fetchNameById(int id) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getfactory().openSession();
		try {
			Query query = session.getNamedQuery("fetchNameById");
			query.setParameter("id", id);

			List l = query.list();
			return l;

		} catch (HibernateException e) {
			System.err.println("exception in fetchNameById" + e.getMessage());
		} finally {
			session.close();
		}
		return null;
	}

}
