package com.rak.rakapp.DAO;

import java.util.List;

import com.rak.rakapp.DTO.XworkzDTO;

public interface XworkzDAO {
	public void save(List<XworkzDTO> list);
	
	public List<XworkzDTO> fetchNameById(int id);
}
