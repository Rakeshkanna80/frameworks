package com.rak.rakapp.DTO;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "xworkz_table")
@NamedNativeQueries(value = { @NamedNativeQuery(name = "fetchNameById", query = "select s_name from xworkz_table where s_id=:id") })
public class XworkzDTO implements Serializable {
	@Id
	@GenericGenerator(name = "xworkz", strategy = "increment")
	@GeneratedValue(generator="xworkz")

	private int s_id;
	@Columns(columns = { @Column })
	private String s_name;
	private String course;

	public XworkzDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "XworkzDTO [s_id=" + s_id + ", s_name=" + s_name + ", course=" + course + "]";
	}

}
